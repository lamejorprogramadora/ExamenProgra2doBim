﻿Module Module2
    Public promedio As String

End Module
