﻿Imports MySql.Data.MySqlClient
Public Class Form2
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Tabla As New DataTable
        Dim conexion As MySqlConnection
        Dim Ds As New DataSet
        conexion = New MySql.Data.MySqlClient.MySqlConnection
        conexion.ConnectionString = "server = 127.0.0.1; user = root; database = ninalogin;"
        Dim insertar As New MySqlDataAdapter("insert into login (username, nombre, contraseña) values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "')", conectarmysql)

        Try
            insertar.Fill(Tabla)
            MsgBox("REGISTRO EXITOSO")
        Catch Mierror As MySqlException
            MsgBox("ERROR, REGISTRO INVALIDO")
        Finally
        End Try
        Me.DialogResult = System.Windows.Forms.DialogResult.OK




    End Sub
End Class