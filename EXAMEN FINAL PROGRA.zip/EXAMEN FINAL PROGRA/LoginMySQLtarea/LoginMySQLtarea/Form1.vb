﻿Imports MySql.Data.MySqlClient


Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            conectarmysql = New MySqlConnection("server=localhost;" + "database=ninalogin;user=root;password=;")
            conectarmysql.Open()
            conectarmysqlcomand = New MySqlCommand
            conectarmysqlcomand.CommandType = CommandType.Text
            conectarmysqlcomand.Connection = conectarmysql

        Catch ex As Exception
            MsgBox("ERROR, FALTA EJECUTAR EL SQL: " + ex.Message, MsgBoxStyle.Critical, "ERROR DE BASE DE DATOS")


        End Try

    End Sub
    Private Sub button1_click(sender As Object, e As EventArgs) Handles Button1.Click
        conectarmysqlcomand.CommandText = "SELECT * FROM login WHERE username='" + TextBox1.Text + "'AND contraseña='" + TextBox2.Text + "'"
        Dim nina As MySqlDataReader
        nina = conectarmysqlcomand.ExecuteReader
        If nina.HasRows <> False Then
            nina.Read()
            MsgBox("Accesso correcto")
            MsgBox(nina.GetString("nombre"))
            MDIParent1.Show()
        Else
            MsgBox("ERROR, ACCESSO DENEGADO")
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form2.Show()

    End Sub
End Class
